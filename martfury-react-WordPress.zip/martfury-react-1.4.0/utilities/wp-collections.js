// Each collection has collection
export const homepageCollections = [2886, 93];
export const homepageCollections = [2886, 93];
export const homepageCollections = [2886, 93];

const WPCollections = {
    ...homepageCollections,
};

export default WPCollections;
