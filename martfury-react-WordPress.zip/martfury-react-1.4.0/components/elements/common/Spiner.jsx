import React from 'react';

const Spiner = () => {
    return (
        <div className="ps-spiner-wraper">
            <div className="ps-spiner--ripple">
            </div>
        </div>

    );
};

export default Spiner;
