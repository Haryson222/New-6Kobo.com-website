import React from 'react';

const WidgetEarningSidebar = () => {
    return (
        <div className="ps-block--earning-count">
            <small>Earning</small>
            <h3>$12,560.55</h3>
        </div>
    );
};

export default WidgetEarningSidebar;
