## MARTFURY ADMIN TEMPLATE - REACT VERSION v1.0.0

Author: nouthemes

Homepage:
[Nouthemes](https://themeforest.net/user/nouthemes/portfolio)

More information, please visit
[Martfury React](https://themeforest.net/item/martfury-multipurpose-marketplace-react-ecommerce-template/25783100)

### Installation

```bash
npm install
```

or Yarn

```bash
yarn install
```

### Develope

```bash
yarn dev
```

More informations, please refer:
[https://nextjs.org/docs/deployment](https://nextjs.org/docs/deployment)
