# Martfury Restfull API - Powerful by Strapi CMS

Author: nouthemes
Developed: diaryforlife

Homepage: [Nouthemes](https://themeforest.net/user/nouthemes)


##NOTE
**Strapi 3 doesn't support Node 16**

## Credentials
Email: admin@admin.com

Password: Admin@123
