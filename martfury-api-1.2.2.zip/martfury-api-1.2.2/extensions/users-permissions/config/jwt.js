module.exports = {
  jwtSecret: process.env.JWT_SECRET || '2a1b9159-9b30-4ec6-af72-b31c5ffe7a15'
};