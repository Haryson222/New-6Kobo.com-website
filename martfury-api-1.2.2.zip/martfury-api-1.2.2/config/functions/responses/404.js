'use strict';

module.exports = async (/* ctx */) => {
  // return ctx.notFound('My custom message 404');
};
